#include <SubsetSumSolver.h>



 bool SSPSolverPD::solve(const std::vector< long> &input,
                            long value, std::vector< char> &output) {
    
    output.resize(input.size());
    return false;
    
}
