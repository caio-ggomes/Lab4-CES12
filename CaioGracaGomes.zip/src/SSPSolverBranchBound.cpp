#include <SubsetSumSolver.h>



 bool SSPSolverBranchBound::solve(const std::vector< long> &input,
                            long value, std::vector< char> &output) {
    
    
    return false;
    
}
